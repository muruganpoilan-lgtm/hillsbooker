"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "./AuthProvider";
import { useLang } from "./LangProvider";
import { LANGS } from "../lib/i18n";

export default function Header() {
  const { ready, token, role, logout } = useAuth();
  const router = useRouter();
  const { t, lang, setLang } = useLang();

  return (
    <header className="site-header">
      <Link href="/" className="brand">
        <img src="/logo-mark.png" alt="" className="brand-logo" />
        Hill Booker
      </Link>
      <nav className="nav" aria-label="Main">
        <Link href="/vehicles">{t("nav.cars")}</Link>
        <Link href="/packages">{t("nav.packages")}</Link>
        <Link href="/plan-trip">{t("nav.planTrip")}</Link>
        <Link href="/blog">{t("nav.blog")}</Link>
        {ready && token ? (
          <>
            {role === "admin" && <Link href="/dashboard/overview">{t("nav.admin")}</Link>}
            {(role === "owner" || role === "operator") && <Link href="/dashboard/home">{t("nav.hostPanel")}</Link>}
            {role === "guest" && <Link href="/dashboard">{t("nav.becomeHost")}</Link>}
            <Link href="/account">{t("nav.account")}</Link>
            <button
              type="button"
              className="link-btn"
              onClick={() => {
                logout();
                router.push("/");
              }}
            >
              {t("nav.logout")}
            </button>
          </>
        ) : ready ? (
          <>
            <Link href="/login">{t("nav.login")}</Link>
            <Link href="/register" className="btn btn-small">
              {t("nav.signup")}
            </Link>
          </>
        ) : null}
        <span className="lang-switch" role="group" aria-label={t("lang.label")}>
          {LANGS.map(([code, label]) => (
            <button key={code} type="button" className={lang === code ? "on" : ""} aria-pressed={lang === code} lang={code} onClick={() => setLang(code)}>
              {label}
            </button>
          ))}
        </span>
      </nav>
    </header>
  );
}
