import re
from datetime import date
from urllib.parse import urlparse

from pydantic import BaseModel, EmailStr, Field, model_validator, field_validator


def _clean_map_url(v):
    """Only an https Google Maps link is accepted. Empty means none."""
    v = (v or "").strip()
    if not v:
        return ""
    u = urlparse(v)
    host = (u.hostname or "").lower()
    allowed = ("goo.gl", "g.page", "google.com", "google.co.in")
    ok = u.scheme == "https" and any(host == d or host.endswith("." + d) for d in allowed)
    if not ok:
        raise ValueError("Paste a Google Maps link (it starts with https://maps.app.goo.gl or https://www.google.com/maps)")
    return v[:500]


def coords_from_map_url(url):
    """Latitude and longitude from a long Google Maps link (.../@11.41,76.69,... or !3d..!4d..). Short links have none."""
    m = re.search(r"@(-?\d+\.\d+),(-?\d+\.\d+)", url or "") or re.search(r"!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)", url or "")
    if not m:
        return None
    lat, lng = float(m.group(1)), float(m.group(2))
    return (lat, lng) if -90 <= lat <= 90 and -180 <= lng <= 180 else None


def _clean_nearby(v):
    lines = [" ".join(x.split()) for x in (v or "").splitlines()]
    lines = [x[:120] for x in lines if x][:10]
    return "\n".join(lines)


class RegisterIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    phone: str | None = None
    password: str = Field(min_length=8, max_length=100)
    role: str = Field(default="guest", pattern="^(guest|owner|operator)$")


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class PropertyIn(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    type: str = Field(pattern="^(hotel|homestay|apartment|resort)$")
    description: str | None = None
    city: str = Field(min_length=1, max_length=80)
    address: str | None = None
    lat: float | None = None
    lng: float | None = None
    map_url: str | None = None
    nearby: str | None = None
    advance_percent: int = Field(default=100, ge=10, le=100)  # share paid online when booking
    min_notice_days: int = Field(default=2, ge=0, le=14)  # earliest check-in = today + this many days
    amenity_ids: list[int] = []
    photo_urls: list[str] = []
    owner_id: str | None = None  # admins only: create the property on behalf of this owner

    @field_validator("map_url")
    @classmethod
    def _map(cls, v):
        return _clean_map_url(v) or None

    @field_validator("nearby")
    @classmethod
    def _near(cls, v):
        return _clean_nearby(v) or None


class PropertyUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=150)
    type: str | None = Field(default=None, pattern="^(hotel|homestay|apartment|resort)$")
    description: str | None = None
    city: str | None = Field(default=None, min_length=1, max_length=80)
    address: str | None = None
    map_url: str | None = None
    nearby: str | None = None
    advance_percent: int | None = Field(default=None, ge=10, le=100)
    min_notice_days: int | None = Field(default=None, ge=0, le=14)
    amenity_ids: list[int] | None = None

    @field_validator("map_url")
    @classmethod
    def _map(cls, v):
        return _clean_map_url(v)  # empty text clears it

    @field_validator("nearby")
    @classmethod
    def _near(cls, v):
        return _clean_nearby(v)  # empty text clears it


BED_TYPES = "^(single|double|queen|king|twin|bunk)$"


class RoomTypeIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    max_guests: int = Field(default=2, ge=1, le=20)
    base_price: float = Field(ge=0)
    total_rooms: int = Field(ge=1, le=500)
    bed_type: str | None = Field(default=None, pattern=BED_TYPES)
    bed_count: int = Field(default=1, ge=1, le=10)


class RoomTypeUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=100)
    max_guests: int | None = Field(default=None, ge=1, le=20)
    base_price: float | None = Field(default=None, ge=0)
    total_rooms: int | None = Field(default=None, ge=1, le=500)
    bed_type: str | None = Field(default=None, pattern=BED_TYPES)
    bed_count: int | None = Field(default=None, ge=1, le=10)


class InventoryIn(BaseModel):
    start: date
    end: date  # last night to open, inclusive
    rooms_open: int = Field(ge=0)  # total rooms open for sale each night; rooms already booked are subtracted
    price: float | None = Field(default=None, ge=0)

    @model_validator(mode="after")
    def check_range(self):
        if self.end < self.start:
            raise ValueError("end must be on or after start")
        if (self.end - self.start).days > 366:
            raise ValueError("Set at most one year at a time")
        return self


class BookingIn(BaseModel):
    room_type_id: str
    check_in: date
    check_out: date
    rooms: int = Field(default=1, ge=1, le=10)
    guests: int = Field(default=1, ge=1, le=40)  # adults + children
    children: int = Field(default=0, ge=0, le=39)  # how many of the guests are children; at least one adult is needed
    coupon_code: str | None = Field(default=None, max_length=40)
    child_ages: list[int] = Field(default_factory=list, max_length=39)  # age of each child at check-out, 0-17

    @model_validator(mode="after")
    def check_dates(self):
        if any(a < 0 or a > 17 for a in self.child_ages):
            raise ValueError("Child ages must be between 0 and 17")
        if self.child_ages and len(self.child_ages) != self.children:
            raise ValueError("Give one age for each child")
        if self.check_out <= self.check_in:
            raise ValueError("check_out must be after check_in")
        if (self.check_out - self.check_in).days > 30:
            raise ValueError("Stays are limited to 30 nights")
        if self.check_in < date.today():
            raise ValueError("check_in can't be in the past")
        return self


VEHICLE_KINDS = "^(car|suv|van|traveller|mini_bus|bus)$"


class VehicleIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    kind: str = Field(pattern=VEHICLE_KINDS)
    seats: int = Field(ge=1, le=80)
    ac: bool = True
    city: str = Field(min_length=1, max_length=80)
    description: str | None = Field(default=None, max_length=2000)
    price_per_day: float = Field(ge=0, le=1_000_000)
    km_per_day: int | None = Field(default=None, ge=1, le=2000)
    extra_km_rate: float | None = Field(default=None, ge=0, le=1000)
    quantity: int = Field(default=1, ge=1, le=50)
    advance_percent: int = Field(default=100, ge=10, le=100)


class VehicleUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=100)
    kind: str | None = Field(default=None, pattern=VEHICLE_KINDS)
    seats: int | None = Field(default=None, ge=1, le=80)
    ac: bool | None = None
    city: str | None = Field(default=None, min_length=1, max_length=80)
    description: str | None = Field(default=None, max_length=2000)
    price_per_day: float | None = Field(default=None, ge=0, le=1_000_000)
    km_per_day: int | None = Field(default=None, ge=1, le=2000)
    extra_km_rate: float | None = Field(default=None, ge=0, le=1000)
    quantity: int | None = Field(default=None, ge=1, le=50)
    advance_percent: int | None = Field(default=None, ge=10, le=100)


class TripIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    from_place: str | None = Field(default=None, max_length=80)
    to_place: str | None = Field(default=None, max_length=80)
    details: str | None = Field(default=None, max_length=1000)
    price: float = Field(ge=0, le=1_000_000)


class TripUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=120)
    from_place: str | None = Field(default=None, max_length=80)
    to_place: str | None = Field(default=None, max_length=80)
    details: str | None = Field(default=None, max_length=1000)
    price: float | None = Field(default=None, ge=0, le=1_000_000)
    active: bool | None = None


class VehicleBookingIn(BaseModel):
    vehicle_id: str
    trip_id: str | None = None          # set for a fixed-price trip; leave empty to hire by the day
    start_date: date
    end_date: date | None = None        # by the day only; a trip is one date
    count: int = Field(default=1, ge=1, le=20)
    passengers: int = Field(default=1, ge=1, le=200)
    pickup: str | None = Field(default=None, max_length=200)
    note: str | None = Field(default=None, max_length=500)

    @model_validator(mode="after")
    def check_dates(self):
        if self.start_date < date.today():
            raise ValueError("The date can't be in the past")
        if self.trip_id is None:
            if self.end_date is None:
                self.end_date = self.start_date
            if self.end_date < self.start_date:
                raise ValueError("end_date can't be before start_date")
            if (self.end_date - self.start_date).days >= 30:
                raise ValueError("Hire is limited to 30 days")
        else:
            self.end_date = self.start_date
        return self
