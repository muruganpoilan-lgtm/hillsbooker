from datetime import date, timedelta

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel, Field

from ..auth import require_role
from ..config import settings
from ..db import get_conn
from ..schemas import InventoryIn, PropertyIn, PropertyUpdate, RoomTypeIn, RoomTypeUpdate, coords_from_map_url
from ..storage import delete_image, save_image

REMOVED_KEEP_DAYS = 30  # removed listings stay on the server this long before they are deleted

router = APIRouter(prefix="/owner", tags=["owner and admin"])
owner_only = require_role("owner", "operator", "admin")  # hosts can list properties and vehicles; admins manage everything


def _own_property(cur, property_id: str, user: dict):
    cur.execute("SELECT owner_id FROM properties WHERE id = %s", (property_id,))
    row = cur.fetchone()
    if not row:
        raise HTTPException(404, "Property not found")
    if user["role"] != "admin" and str(row["owner_id"]) != user["id"]:
        raise HTTPException(403, "That's not your property")


def _own_room_type(cur, room_type_id: str, user: dict) -> dict:
    cur.execute("SELECT id, property_id, total_rooms FROM room_types WHERE id = %s", (room_type_id,))
    rt = cur.fetchone()
    if not rt:
        raise HTTPException(404, "Room type not found")
    _own_property(cur, str(rt["property_id"]), user)
    return rt


def _upload_photos(table: str, parent_col: str, parent_id: str, folder: str, files: list[UploadFile], user: dict, check, moderated: bool = False):
    """Shared photo upload for properties and room types. Files are saved first, then recorded in one
    transaction; if the database step fails, the saved files are removed again."""
    if not files:
        raise HTTPException(400, "Choose at least one photo")
    saved: list[tuple[str, str]] = []
    try:
        with get_conn() as conn, conn.cursor() as cur:
            check(cur, parent_id, user)
            cur.execute(f"SELECT COUNT(*) AS n, COALESCE(MAX(position), -1) AS last FROM {table} WHERE {parent_col} = %s", (parent_id,))
            info = cur.fetchone()
            if info["n"] + len(files) > settings.max_photos_per_item:
                raise HTTPException(400, f"You can add up to {settings.max_photos_per_item} photos. This one has {info['n']}")
            for f in files:
                saved.append(save_image(f, folder))
            out = []
            # Photos from hosts wait for the admin's approval. The admin's own uploads go live straight away.
            review = ", status" if moderated else ""
            review_val = (", %s" if moderated else "")
            state = "approved" if user["role"] == "admin" else "pending"
            for i, (url, key) in enumerate(saved, start=1):
                params = (parent_id, url, key, info["last"] + i) + ((state,) if moderated else ())
                cur.execute(
                    f"INSERT INTO {table} ({parent_col}, url, storage_key, position{review}) VALUES (%s, %s, %s, %s{review_val}) RETURNING id, url, position" + (", status" if moderated else ""),
                    params,
                )
                out.append(cur.fetchone())
            return out
    except Exception:
        for _, key in saved:
            delete_image(key)
        raise


def _delete_photo(table: str, parent_col: str, parent_id: str, photo_id: int, user: dict, check):
    with get_conn() as conn, conn.cursor() as cur:
        check(cur, parent_id, user)
        cur.execute(f"DELETE FROM {table} WHERE id = %s AND {parent_col} = %s RETURNING storage_key", (photo_id, parent_id))
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, "Photo not found")
    delete_image(row["storage_key"])
    return {"deleted": photo_id}


# ---------- properties ----------

@router.post("/properties", status_code=201)
def create_property(body: PropertyIn, user: dict = Depends(owner_only)):
    with get_conn() as conn, conn.cursor() as cur:
        owner_id = user["id"]
        if body.owner_id:
            if user["role"] != "admin":
                raise HTTPException(403, "Only admins can create a property for another owner")
            cur.execute("SELECT id FROM users WHERE id = %s AND role = 'owner'", (body.owner_id,))
            if not cur.fetchone():
                raise HTTPException(404, "That owner account doesn't exist")
            owner_id = body.owner_id
        # Listings made by an admin are trusted and go live at once; owners' listings wait for approval.
        status = "approved" if user["role"] == "admin" else "pending"
        lat, lng = body.lat, body.lng
        if lat is None or lng is None:
            lat, lng = coords_from_map_url(body.map_url) or (None, None)
        cur.execute(
            """INSERT INTO properties (owner_id, name, type, description, city, address, lat, lng, map_url, nearby, status, advance_percent, min_notice_days)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING id""",
            (owner_id, body.name, body.type, body.description, body.city, body.address, lat, lng, body.map_url, body.nearby, status, body.advance_percent, body.min_notice_days),
        )
        pid = cur.fetchone()["id"]
        for amenity_id in body.amenity_ids:
            cur.execute(
                "INSERT INTO property_amenities (property_id, amenity_id) VALUES (%s, %s) ON CONFLICT DO NOTHING",
                (pid, amenity_id),
            )
        for pos, url in enumerate(body.photo_urls):
            cur.execute(
                "INSERT INTO property_photos (property_id, url, position, status) VALUES (%s, %s, %s, %s)",
                (pid, url, pos, "approved" if user["role"] == "admin" else "pending"),
            )
    return {"id": pid, "status": status}


@router.get("/properties")
def my_properties(user: dict = Depends(owner_only)):
    sql = "SELECT id, name, type, city, status, rating_avg, rating_count FROM properties WHERE status <> 'removed'"
    params: tuple = ()
    if user["role"] != "admin":
        sql += " AND owner_id = %s"
        params = (user["id"],)
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql + " ORDER BY created_at DESC", params)
        return cur.fetchall()


@router.get("/properties/{property_id}")
def my_property_detail(property_id: str, user: dict = Depends(owner_only)):
    """Everything an owner needs to edit a listing: photos and rooms with their photos."""
    with get_conn() as conn, conn.cursor() as cur:
        _own_property(cur, property_id, user)
        cur.execute(
            "SELECT id, name, type, description, city, address, lat, lng, map_url, nearby, status, advance_percent, min_notice_days FROM properties WHERE id = %s",
            (property_id,),
        )
        prop = cur.fetchone()
        cur.execute("SELECT id, url, position, status, reject_reason FROM property_photos WHERE property_id = %s ORDER BY position", (property_id,))
        prop["photos"] = cur.fetchall()
        cur.execute(
            "SELECT id, name, max_guests, base_price, total_rooms, bed_type, bed_count FROM room_types WHERE property_id = %s ORDER BY base_price",
            (property_id,),
        )
        rooms = cur.fetchall()
        for r in rooms:
            cur.execute("SELECT id, url, position, status, reject_reason FROM room_type_photos WHERE room_type_id = %s ORDER BY position", (r["id"],))
            r["photos"] = cur.fetchall()
        prop["room_types"] = rooms
        cur.execute("SELECT amenity_id FROM property_amenities WHERE property_id = %s", (property_id,))
        prop["amenity_ids"] = [r["amenity_id"] for r in cur.fetchall()]
        return prop


@router.patch("/properties/{property_id}")
def update_property(property_id: str, body: PropertyUpdate, user: dict = Depends(owner_only)):
    changes = body.model_dump(exclude_none=True)
    amenity_ids = changes.pop("amenity_ids", None)
    if not changes and amenity_ids is None:
        raise HTTPException(400, "Nothing to change")
    with get_conn() as conn, conn.cursor() as cur:
        _own_property(cur, property_id, user)
        if "map_url" in changes and "lat" not in changes and "lng" not in changes:
            pt = coords_from_map_url(changes["map_url"])
            if pt:
                changes["lat"], changes["lng"] = pt
        if amenity_ids is not None:
            cur.execute("SELECT id FROM amenities WHERE id = ANY(%s)", (amenity_ids,))
            if len(cur.fetchall()) != len(set(amenity_ids)):
                raise HTTPException(400, "Unknown amenity")
            cur.execute("DELETE FROM property_amenities WHERE property_id = %s", (property_id,))
            for aid in set(amenity_ids):
                cur.execute("INSERT INTO property_amenities (property_id, amenity_id) VALUES (%s, %s)", (property_id, aid))
        if changes:
            sets = ", ".join(f"{col} = %s" for col in changes)  # column names come from the schema model
            cur.execute(f"UPDATE properties SET {sets} WHERE id = %s", (*changes.values(), property_id))
        # An owner who edits a rejected listing sends it back for review.
        if user["role"] != "admin":
            cur.execute("UPDATE properties SET status = 'pending' WHERE id = %s AND status = 'rejected'", (property_id,))
        cur.execute("SELECT status FROM properties WHERE id = %s", (property_id,))
        return {"id": property_id, "status": cur.fetchone()["status"]}


@router.delete("/properties/{property_id}")
def remove_property(property_id: str, user: dict = Depends(owner_only)):
    """Hides the property from guests. The data stays on the server for 30 days (admin can restore it),
    then a nightly job deletes it for good. Refused while a guest has an upcoming or in-progress stay."""
    with get_conn() as conn, conn.cursor() as cur:
        _own_property(cur, property_id, user)
        cur.execute(
            """SELECT 1 FROM bookings WHERE property_id = %s
                 AND ((status = 'confirmed' AND check_out >= current_date)
                   OR (status = 'held' AND hold_expires_at > now())) LIMIT 1""",
            (property_id,),
        )
        if cur.fetchone():
            raise HTTPException(409, "Guests have upcoming bookings here. Wait until their stays are over, or cancel them first")
        cur.execute("UPDATE properties SET status = 'removed', removed_at = now() WHERE id = %s AND status <> 'removed'", (property_id,))
    return {"id": property_id, "result": "removed", "kept_days": REMOVED_KEEP_DAYS}


def purge_removed_properties() -> int:
    """Delete properties removed more than 30 days ago. Ones with booking or review history are kept hidden,
    because invoices and payments refer to them."""
    done = 0
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT p.id FROM properties p
               WHERE p.status = 'removed' AND p.removed_at < now() - make_interval(days => %s)
                 AND NOT EXISTS (SELECT 1 FROM bookings b WHERE b.property_id = p.id)
                 AND NOT EXISTS (SELECT 1 FROM reviews r WHERE r.property_id = p.id)""",
            (REMOVED_KEEP_DAYS,),
        )
        ids = [r["id"] for r in cur.fetchall()]
        keys: list[str] = []
        for pid in ids:
            cur.execute(
                """SELECT storage_key FROM property_photos WHERE property_id = %s
                   UNION ALL SELECT ph.storage_key FROM room_type_photos ph JOIN room_types rt ON rt.id = ph.room_type_id WHERE rt.property_id = %s""",
                (pid, pid),
            )
            keys += [r["storage_key"] for r in cur.fetchall()]
            cur.execute("DELETE FROM properties WHERE id = %s", (pid,))
            done += 1
    for key in keys:
        delete_image(key)
    return done


@router.post("/properties/{property_id}/photos", status_code=201)
def upload_property_photos(property_id: str, files: list[UploadFile] = File(...), user: dict = Depends(owner_only)):
    return _upload_photos("property_photos", "property_id", property_id, f"properties/{property_id}", files, user, _own_property, moderated=True)


@router.delete("/properties/{property_id}/photos/{photo_id}")
def delete_property_photo(property_id: str, photo_id: int, user: dict = Depends(owner_only)):
    return _delete_photo("property_photos", "property_id", property_id, photo_id, user, _own_property)


# ---------- rooms ----------

@router.post("/properties/{property_id}/room-types", status_code=201)
def add_room_type(property_id: str, body: RoomTypeIn, user: dict = Depends(owner_only)):
    with get_conn() as conn, conn.cursor() as cur:
        _own_property(cur, property_id, user)
        cur.execute(
            """INSERT INTO room_types (property_id, name, max_guests, base_price, total_rooms, bed_type, bed_count)
               VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING id""",
            (property_id, body.name, body.max_guests, body.base_price, body.total_rooms, body.bed_type, body.bed_count),
        )
        return {"id": cur.fetchone()["id"]}


@router.patch("/room-types/{room_type_id}")
def update_room_type(room_type_id: str, body: RoomTypeUpdate, user: dict = Depends(owner_only)):
    changes = body.model_dump(exclude_none=True)
    if not changes:
        raise HTTPException(400, "Nothing to change")
    with get_conn() as conn, conn.cursor() as cur:
        rt = _own_room_type(cur, room_type_id, user)
        new_total = changes.get("total_rooms")
        if new_total is not None and new_total < rt["total_rooms"]:
            cur.execute(
                "SELECT COALESCE(MAX(available), 0) AS most FROM room_inventory WHERE room_type_id = %s AND day >= %s",
                (room_type_id, date.today()),
            )
            if cur.fetchone()["most"] > new_total:
                raise HTTPException(409, "Some upcoming nights have more rooms open than that. Lower the open rooms for those dates first")
        sets = ", ".join(f"{col} = %s" for col in changes)  # column names come from the schema model, never from the request
        cur.execute(f"UPDATE room_types SET {sets} WHERE id = %s", (*changes.values(), room_type_id))
        return {"id": room_type_id, "updated": list(changes)}


@router.delete("/room-types/{room_type_id}")
def delete_room_type(room_type_id: str, user: dict = Depends(owner_only)):
    with get_conn() as conn, conn.cursor() as cur:
        _own_room_type(cur, room_type_id, user)
        cur.execute("SELECT 1 FROM bookings WHERE room_type_id = %s LIMIT 1", (room_type_id,))
        if cur.fetchone():
            raise HTTPException(409, "This room has bookings, so it can't be deleted. Close its dates instead")
        cur.execute("SELECT storage_key FROM room_type_photos WHERE room_type_id = %s", (room_type_id,))
        keys = [r["storage_key"] for r in cur.fetchall()]
        cur.execute("DELETE FROM room_types WHERE id = %s", (room_type_id,))
    for key in keys:
        delete_image(key)
    return {"deleted": room_type_id}


@router.post("/room-types/{room_type_id}/photos", status_code=201)
def upload_room_photos(room_type_id: str, files: list[UploadFile] = File(...), user: dict = Depends(owner_only)):
    return _upload_photos("room_type_photos", "room_type_id", room_type_id, f"rooms/{room_type_id}", files, user, _own_room_type, moderated=True)


@router.delete("/room-types/{room_type_id}/photos/{photo_id}")
def delete_room_photo(room_type_id: str, photo_id: int, user: dict = Depends(owner_only)):
    return _delete_photo("room_type_photos", "room_type_id", room_type_id, photo_id, user, _own_room_type)


@router.put("/room-types/{room_type_id}/inventory")
def set_inventory(room_type_id: str, body: InventoryIn, user: dict = Depends(owner_only)):
    """Open rooms for sale for a date range. Rooms already booked are subtracted automatically."""
    with get_conn() as conn, conn.cursor() as cur:
        rt = _own_room_type(cur, room_type_id, user)
        if body.rooms_open > rt["total_rooms"]:
            raise HTTPException(400, f"This room type only has {rt['total_rooms']} rooms")
        cur.execute(
            """INSERT INTO room_inventory (room_type_id, day, available, price)
               SELECT %(rt)s, d::date, GREATEST(%(open)s - COALESCE(b.booked, 0) - COALESCE(x.ext, 0), 0), %(price)s
               FROM generate_series(%(start)s::date, %(end)s::date, interval '1 day') AS d
               LEFT JOIN LATERAL (
                 SELECT SUM(rooms) AS booked FROM bookings
                 WHERE room_type_id = %(rt)s AND status IN ('held', 'confirmed')
                   AND check_in <= d::date AND check_out > d::date
               ) b ON true
               LEFT JOIN LATERAL (
                 SELECT SUM(wanted) AS ext FROM external_nights
                 WHERE room_type_id = %(rt)s AND day = d::date
               ) x ON true
               ON CONFLICT (room_type_id, day)
               DO UPDATE SET available = EXCLUDED.available, price = COALESCE(EXCLUDED.price, room_inventory.price), blocked = false""",
            {"rt": room_type_id, "open": body.rooms_open, "price": body.price, "start": body.start, "end": body.end},
        )
        # Nights taken on other sites are subtracted above, so they count as fully applied now.
        cur.execute(
            "UPDATE external_nights SET applied = wanted WHERE room_type_id = %s AND day BETWEEN %s AND %s",
            (room_type_id, body.start, body.end),
        )
        return {"nights_updated": (body.end - body.start).days + 1}


class BlockIn(BaseModel):
    days: list[date] = Field(min_length=1, max_length=366)
    blocked: bool


@router.put("/room-types/{room_type_id}/block")
def block_dates(room_type_id: str, body: BlockIn, user: dict = Depends(owner_only)):
    """Block nights so guests cannot book them online, or open them again with all rooms.
    Bookings that already exist are kept. Opening only changes nights that were blocked or never opened."""
    today = date.today()
    days = sorted(set(body.days))
    if days[0] < today:
        raise HTTPException(400, "Past dates can't be changed")
    with get_conn() as conn, conn.cursor() as cur:
        rt = _own_room_type(cur, room_type_id, user)
        if body.blocked:
            cur.execute(
                """INSERT INTO room_inventory (room_type_id, day, available, price, blocked)
                   SELECT %s, d, 0, NULL, true FROM unnest(%s::date[]) AS d
                   ON CONFLICT (room_type_id, day) DO UPDATE SET available = 0, blocked = true""",
                (room_type_id, days),
            )
        else:
            cur.execute(
                """INSERT INTO room_inventory (room_type_id, day, available, price, blocked)
                   SELECT %(rt)s, d, GREATEST(%(total)s - COALESCE(b.booked, 0) - COALESCE(x.ext, 0), 0), NULL, false
                   FROM unnest(%(days)s::date[]) AS d
                   LEFT JOIN LATERAL (
                     SELECT SUM(rooms) AS booked FROM bookings
                     WHERE room_type_id = %(rt)s AND status IN ('held', 'confirmed') AND check_in <= d AND check_out > d
                   ) b ON true
                   LEFT JOIN LATERAL (
                     SELECT SUM(wanted) AS ext FROM external_nights WHERE room_type_id = %(rt)s AND day = d
                   ) x ON true
                   ON CONFLICT (room_type_id, day) DO UPDATE SET available = EXCLUDED.available, blocked = false
                   WHERE room_inventory.blocked OR room_inventory.available = 0""",
                {"rt": room_type_id, "total": rt["total_rooms"], "days": days},
            )
        return {"changed": len(days), "blocked": body.blocked}


class PriceIn(BaseModel):
    days: list[date] = Field(min_length=1, max_length=366)
    price: float | None = Field(default=None, ge=0, le=1000000)  # None puts the usual room price back


@router.put("/room-types/{room_type_id}/price")
def set_price(room_type_id: str, body: PriceIn, user: dict = Depends(owner_only)):
    """Set the price for chosen nights. Nights that are not open yet get the price but stay closed to guests.
    Bookings that already exist keep the price they were made at."""
    days = sorted(set(body.days))
    if days[0] < date.today():
        raise HTTPException(400, "Past dates can't be changed")
    with get_conn() as conn, conn.cursor() as cur:
        _own_room_type(cur, room_type_id, user)
        cur.execute(
            """INSERT INTO room_inventory (room_type_id, day, available, price, blocked)
               SELECT %s, d, 0, %s, false FROM unnest(%s::date[]) AS d
               ON CONFLICT (room_type_id, day) DO UPDATE SET price = EXCLUDED.price""",
            (room_type_id, body.price, days),
        )
        return {"changed": len(days), "price": body.price}


@router.get("/room-types/{room_type_id}/inventory")
def get_inventory(room_type_id: str, start: date | None = None, days: int = 60, user: dict = Depends(owner_only)):
    """Open rooms and price for each night, so owners can see what guests will see."""
    days = max(1, min(days, 366))
    start = start or date.today()
    with get_conn() as conn, conn.cursor() as cur:
        _own_room_type(cur, room_type_id, user)
        cur.execute(
            """SELECT ri.day, ri.available, ri.price, ri.blocked,
                      (SELECT COALESCE(SUM(b.rooms), 0) FROM bookings b
                        WHERE b.room_type_id = ri.room_type_id AND b.status IN ('held', 'confirmed')
                          AND b.check_in <= ri.day AND b.check_out > ri.day) AS booked
               FROM room_inventory ri
               WHERE ri.room_type_id = %s AND ri.day >= %s AND ri.day < %s ORDER BY ri.day""",
            (room_type_id, start, start + timedelta(days=days)),
        )
        return cur.fetchall()


@router.get("/bookings")
def owner_bookings(user: dict = Depends(owner_only)):
    sql = """SELECT b.id, p.name AS property, rt.name AS room_type, u.name AS guest,
                    b.check_in, b.check_out, b.rooms, b.guests, b.children, b.total_amount,
                    COALESCE(b.advance_amount, b.total_amount) AS advance_amount,
                    b.total_amount - COALESCE(b.advance_amount, b.total_amount) AS balance_due, b.status
             FROM bookings b
             JOIN properties p ON p.id = b.property_id
             JOIN room_types rt ON rt.id = b.room_type_id
             JOIN users u ON u.id = b.user_id
             WHERE b.status IN ('confirmed', 'cancelled')"""
    params: tuple = ()
    if user["role"] != "admin":
        sql += " AND p.owner_id = %s"
        params = (user["id"],)
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql + " ORDER BY b.check_in DESC", params)
        return cur.fetchall()


# ---------- host overview: the numbers on the host's home page ----------

@router.get("/overview")
def host_overview(user: dict = Depends(owner_only)):
    """A summary of the signed-in host's own stays and vehicles. Admins see their own listings here, like any host."""
    from .admin import _PAYOUT_READY  # the same "ready to pay out" rule the admin uses

    uid = user["id"]
    today = "(now() AT TIME ZONE 'Asia/Kolkata')::date"
    mine = """
      WITH mine AS (
        SELECT 'stay' AS kind, b.id, b.status, (b.created_at AT TIME ZONE 'Asia/Kolkata')::date AS day, b.total_amount,
               p.name AS item, g.name AS guest, b.guests AS people, b.check_in AS start_date, b.check_out AS end_date
          FROM bookings b JOIN properties p ON p.id = b.property_id JOIN users g ON g.id = b.user_id WHERE p.owner_id = %(u)s
        UNION ALL
        SELECT 'vehicle', b.id, b.status, (b.created_at AT TIME ZONE 'Asia/Kolkata')::date, b.total_amount,
               v.name, g.name, b.passengers, b.start_date, b.end_date
          FROM vehicle_bookings b JOIN vehicles v ON v.id = b.vehicle_id JOIN users g ON g.id = b.user_id WHERE v.operator_id = %(u)s
      )"""
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute("SELECT name FROM users WHERE id = %s", (uid,))
        name = (cur.fetchone() or {}).get("name") or ""
        cur.execute(
            mine
            + f"""SELECT
                   count(*) FILTER (WHERE status = 'confirmed' AND day > {today} - 30) AS month,
                   count(*) FILTER (WHERE status = 'confirmed' AND day > {today} - 7) AS week,
                   count(*) FILTER (WHERE status = 'confirmed' AND start_date = {today} + 1) AS arrivals_tomorrow,
                   count(*) FILTER (WHERE status = 'confirmed' AND start_date BETWEEN {today} AND {today} + 7) AS arrivals_week
                 FROM mine""",
            {"u": uid},
        )
        counts = cur.fetchone()
        # The host's share of what guests paid online in the last 30 days (after commission and refunds).
        cur.execute(
            mine
            + f"""SELECT COALESCE(sum(pm.amount - pm.commission - pm.refunded_amount), 0) AS share
                  FROM payments pm JOIN mine m ON (m.kind = 'stay' AND pm.booking_id = m.id) OR (m.kind = 'vehicle' AND pm.vehicle_booking_id = m.id)
                  WHERE pm.status IN ('paid', 'refunded') AND pm.provider IN ('razorpay', 'cashfree')
                    AND (pm.updated_at AT TIME ZONE 'Asia/Kolkata')::date > {today} - 30""",
            {"u": uid},
        )
        share = cur.fetchone()["share"]
        cur.execute(f"SELECT COALESCE(sum(share), 0) AS due FROM ({_PAYOUT_READY}) r WHERE r.host_id = %s", (uid,))
        due = cur.fetchone()["due"]
        cur.execute("SELECT COALESCE(sum(amount), 0) AS paid FROM payouts WHERE host_id = %s AND status <> 'failed' AND paid_at > now() - interval '30 days'", (uid,))
        paid_out = cur.fetchone()["paid"]
        cur.execute(
            mine
            + f"""SELECT to_char(g.day, 'YYYY-MM-DD') AS day, count(m.id) AS bookings
                  FROM generate_series({today} - 13, {today}, interval '1 day') AS g(day)
                  LEFT JOIN mine m ON m.day = g.day::date AND m.status = 'confirmed'
                  GROUP BY g.day ORDER BY g.day""",
            {"u": uid},
        )
        daily = cur.fetchall()
        cur.execute(
            mine
            + f"""SELECT kind, item, guest, people, start_date, end_date FROM mine
                  WHERE status = 'confirmed' AND start_date >= {today} ORDER BY start_date, item LIMIT 5""",
            {"u": uid},
        )
        coming = cur.fetchall()
        cur.execute(
            """SELECT id, name, type, city, status FROM properties WHERE owner_id = %s AND status <> 'removed'
               ORDER BY created_at DESC LIMIT 6""",
            (uid,),
        )
        properties = cur.fetchall()
        cur.execute(
            "SELECT id, name, kind, city, status FROM vehicles WHERE operator_id = %s AND status <> 'removed' ORDER BY created_at DESC LIMIT 6",
            (uid,),
        )
        vehicles = cur.fetchall()
    return {"name": name, "counts": counts, "share_30d": share, "due": due, "paid_out_30d": paid_out, "daily": daily, "coming": coming, "properties": properties, "vehicles": vehicles}
